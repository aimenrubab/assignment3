<?php
	$db = mysqli_connect("localhost" , "root" , "","users");
if(!($db))
    die("Connection failed");
?>