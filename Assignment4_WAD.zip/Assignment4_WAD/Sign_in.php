<?php
   include("config.php");
   session_start();

   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form

      $my_email = mysqli_real_escape_string($db,$_POST['Email']);
      $my_password = mysqli_real_escape_string($db,$_POST['Password']);

      $sql = "SELECT userId FROM users WHERE Email = '$my_email' and Password = '$my_password'";
      $result = $result = mysqli_query($db, $sql) or die( mysqli_error($db));
      $row = mysqli_fetch_array($result,MYSQLI_ASSOC);
      $active = $row['active'];
      $count = mysqli_num_rows($result);

      // If result matched $myusername and $mypassword, table row must be 1 row

      if($count == 1) {
         session_register("myemail");
         $_SESSION['login_user'] = $myemail;

         header("location: Welcome.php");
      }else {
         $error = "Your Login Name or Password is invalid";
      }
   }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="description" content="UCP Section H Assignment 3">
    <meta name="author" content="Aimen Rubab">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/bootstrap4.css">
    <link rel="stylesheet" type="text/css" href="css/main.css">
</head>
<body>

<header class="row header">
    <div class="col-3 soundcloud">
        &nbsp; &nbsp;&nbsp; &nbsp;<img src="css/s.jpg" width="80" height="50">
        &nbsp; &nbsp; Home &nbsp; &nbsp;Stream &nbsp; &nbsp; Collection</div>

    <div class="col-4 searchBar">
        <input type="text" value="Search for artists,tracks,bands,products" placeholder="Search" size="60%"></div>

    <div class="col-2 Signup">

        &nbsp; &nbsp; <button class="first"><a href="Sign_in.php">Sign in</a></button>
    </div>

    <div class="col-3 createA">


        &nbsp; &nbsp;<button class="second"><a href="Account.php">Create account</a></button>
    </div>

</header>

<div class="MainDiv">
    <div id="LoginPage">
        <p>Login</p>
        <form action="index.php" method="post">

            <input class="input"	name="Email" id="userId"  	placeholder="Your email address or profile URL *" type="email"/><br>
            <input class="input"	name="Password"	id="userId" placeholder="Your password" type="password"/><br>
            <input class="button" placeholder="" name="" type="submit" value="Continue"/>
        </form>

    </div>
</div>

<div class="footer">
    <p>Legal - Privacy - Cookies - Imprint - Charts - Popular searches</p><br>
    <span>Language: English (US)</span>
</div>

</body>
</html>