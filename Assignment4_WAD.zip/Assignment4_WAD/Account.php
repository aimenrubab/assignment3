<?php
require_once ('config.php');
if(isset($_POST['insert_user'])){
    $UserName = $_POST["UserName"];
    $Email = $_POST["Email"];
    $Password = $_POST["Password"];
    $ConfirmPassword = $_POST["ConfirmPassword"];


    $insert_user ="INSERT INTO users (UserName,Email,Password,ConfirmPassword) VALUES ('$UserName','$Email','$Password','$ConfirmPassword');";
    if(!mysqli_query($db,$insert_user))
    {
        echo 'not inserted';
    }
    else
    {
        echo 'inserted';
    }

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="description" content="UCP Section H Assignment 3">
    <meta name="author" content="Aimen Rubab">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/bootstrap4.css">
    <link rel="stylesheet" type="text/css" href="css/main.css">
</head>
<body>

<header class="row header">
    <div class="col-3 soundcloud">
        &nbsp; &nbsp;&nbsp; &nbsp;<img src="css/s.jpg" width="80" height="50">
        &nbsp; &nbsp; Home &nbsp; &nbsp;Stream &nbsp; &nbsp; Collection</div>

    <div class="col-4 searchBar">
        <input type="text" value="Search for artists,tracks,bands,products" placeholder="Search" size="60%"></div>

    <div class="col-2 Signup">

        &nbsp; &nbsp; <button class="first"><a href="Sign_in.php">Sign in</a></button>
    </div>

    <div class="col-3 createA">


        &nbsp; &nbsp;<button class="second"><a href="Account.php">Create account</a></button>
    </div>

</header>

<div class="MainDiv">
    <div id="LoginPage">
        <p>Sign up</p>
        <form action="Account.php" method="post" >
            <input class="input" name="UserName" id="UserName"   placeholder="Your name" type="name"/><br>
            <input class="input" name="Email" id="Email" placeholder="Your email" type="email"/><br>
            <input class="input" name="Password" id="Password" placeholder="Your password" type="password"/><br>
            <input class="input" name="ConfirmPassword" id="ConfirmPassword" placeholder="Confirm password" type="password"/><br>
            <input class="button" placeholder="" name="insert_user" type="submit" value="Continue"/>
        </form>

    </div>
</div>

<div class="footer">
    <p>Legal - Privacy - Cookies - Imprint - Charts - Popular searches</p><br>
    <span>Language: English (US)</span>
</div>



</body>
</html>