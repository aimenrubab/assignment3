CREATE TABLE IF NOT EXISTS `users` (
`userId` int(8) NOT NULL,
  `UserName` varchar(55) NOT NULL,
  `Email` varchar(55) NOT NULL,
  `Password` varchar(55) NOT NULL,
  `Confirm Password` varchar(55) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;


ALTER TABLE `users`
 ADD PRIMARY KEY (`userId`);

ALTER TABLE `users`
MODIFY `userId` int(8) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=0;